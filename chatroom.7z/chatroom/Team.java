package chatroom;

public enum Team {
  RED, BLUE
}
