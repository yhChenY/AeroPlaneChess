package chatroom;

public class demoVan {

  public static void main(String[] args) {
    ChatRoom chatRoom1 = new ChatRoom("Van");
  }
}
