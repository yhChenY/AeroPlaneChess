package chatroom;

public class demoFeng {
  public static void main(String[] args) {
    ChatRoom chatRoom2 = new ChatRoom("Feng");
  }

}
