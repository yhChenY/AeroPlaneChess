package chatroom;

public class demoChen {
  public static void main(String[] args) {
    ChatRoom chatRoom3 = new ChatRoom("Chen");
  }
}
