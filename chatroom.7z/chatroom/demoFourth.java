package chatroom;

public class demoFourth {
  public static void main(String[] args) {
    ChatRoom chatRoom2 = new ChatRoom("Fourth");
  }

}
